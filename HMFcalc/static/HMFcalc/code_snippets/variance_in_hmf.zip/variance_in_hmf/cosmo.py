'''
Created on Jun 7, 2013

@author: Steven
'''

class Cosmo(object):
    def __init__(self):
        pass

    def get_ombh2(self):
        return self.__ombh2

    def get_omch2(self):
        return self.__omch2

    def get_n(self):
        return self.__n

    def get_H0(self):
        try:
            return self.__H0
        except:
            return 100 * self.get_h()

    def get_sigma_8(self):
        return self.__sigma_8


    def get_ommh2(self):
        try:
            return self.__ommh2
        except:
            return self.get_ombh2() + self.get_omch2()

    def get_omegab(self):
        try:
            return self.__omegab
        except:
            return self.get_ombh2() / self.get_h() ** 2

    def get_omegac(self):
        try:
            return self.__omegac
        except:
            return self.get_omch2() / self.get_h() ** 2

    def get_omegam(self):
        try:
            return self.__omegam
        except:
            return self.get_ommh2() / self.get_h() ** 2

    def get_omegav(self):
        try:
            return self.__omegav
        except:
            return 1 - self.get_omegam()


    def get_omegak(self):
        return self.__omegak


    def get_h(self):
        try:
            return self.__h
        except:
            try:
                return self.get_H0() / 100.0
            except:
                #Planck condition
                return (0.695 * self.get_ombh2() ** 0.54 / self.get_ommh2()) ** (1 / 1.2)

    def set_ombh2(self, value):
        self.__ombh2 = value


    def set_omch2(self, value):
        self.__omch2 = value


    def set_n(self, value):
        self.__n = value

    def set_H0(self, value):
        self.__H0 = value


    def set_sigma_8(self, value):
        self.__sigma_8 = value


    def set_ommh2(self, value):
        self.__ommh2 = value


    def set_omegab(self, value):
        self.__omegab = value


    def set_omegac(self, value):
        self.__omegac = value


    def set_omegam(self, value):
        self.__omegam = value


    def set_omegav(self, value):
        self.__omegav = value


    def set_omegak(self, value):
        self.__omegak = value


    def set_h(self, value):
        self.__h = value


    def del_ombh2(self):
        del self.__ombh2


    def del_omch2(self):
        del self.__omch2


    def del_H0(self):
        del self.__H0


    def del_sigma_8(self):
        del self.__sigma_8


    def del_ommh2(self):
        del self.__ommh2


    def del_omegab(self):
        del self.__omegab


    def del_omegac(self):
        del self.__omegac


    def del_omegam(self):
        del self.__omegam


    def del_omegav(self):
        del self.__omegav


    def del_omegak(self):
        del self.__omegak


    def del_h(self):
        del self.__h

    def del_n(self):
        del self.__n

    ombh2 = property(get_ombh2, set_ombh2, del_ombh2, "ombh2's docstring")
    omch2 = property(get_omch2, set_omch2, del_omch2, "omch2's docstring")
    H0 = property(get_H0, set_H0, del_H0, "H0's docstring")
    sigma_8 = property(get_sigma_8, set_sigma_8, del_sigma_8, "sigma_8's docstring")
    ommh2 = property(get_ommh2, set_ommh2, del_ommh2, "ommh2's docstring")
    omegab = property(get_omegab, set_omegab, del_omegab, "omegab's docstring")
    omegac = property(get_omegac, set_omegac, del_omegac, "omegac's docstring")
    omegam = property(get_omegam, set_omegam, del_omegam, "omegam's docstring")
    omegav = property(get_omegav, set_omegav, del_omegav, "omegav's docstring")
    omegak = property(get_omegak, set_omegak, del_omegak, "omegak's docstring")
    h = property(get_h, set_h, del_h, "h's docstring")
    n = property(get_n, set_n, del_n, "n's docstring")
