'''
Created on May 2, 2013

@author: Steven
'''




import matplotlib.pyplot as plt
import matplotlib.ticker as tick
import pandas
import numpy as np
from hmf.Perturbations import Perturbations
#===============================================================================
# SET PARAMETERS
#===============================================================================
fsigma = 'ST'
masses = np.arange(11.0, 14.0, 1.0)
wdm = 1.0  # keV
bfrac = 0.155
realisations = 100
redshift = 0.0
omega_m = 0.314
planck_error = 0.02

planck_cosmo = {'omegab':0.155 * 0.314,
                "omegac"   : (1 - 0.155) * 0.314,
                'omegav' : 1 - 0.314,
                'n'    :0.9616,
                'sigma_8':0.834,
                'H0'    :67.4
                }

#===============================================================================
# BEGIN
#===============================================================================
# We use PLANCK and ST to get WDM functions at given masses, then find omega_M needed to get above this value

pert = Perturbations(masses, z=redshift, WDM=wdm, **planck_cosmo)
wdm_values = pert.MassFunction(fsigma=fsigma)

final_errors = []
errors = np.linspace(0.035, 0.0, 700)
for error in errors:
    omegam = omega_m - error
    planck_cosmo.update({"omegab":bfrac * omegam, "omegac":(1 - bfrac) * omegam})

    pert = Perturbations(masses, z=redshift, **planck_cosmo)
    mf = pert.MassFunction(fsigma=fsigma)

    if mf[0] > wdm_values[0] and len(final_errors) == 0:
        final_errors = final_errors + [error]
    if mf[1] > wdm_values[1] and len(final_errors) == 1:
        final_errors = final_errors + [error]
    if mf[2] > wdm_values[2] and len(final_errors) == 2:
        final_errors = final_errors + [error]
        break

print final_errors



########################################################################################################################
########################################################################################################################
# NOW MAKE PLOTS!!!
########################################################################################################################
########################################################################################################################
dates = np.array([2003, 2007, 2009, 2011, 2012, 2013])
errors = np.array([0.07, 0.034, 0.03, 0.03, 0.0254, 0.02])

# from scipy.interpolate import InterpolatedUnivariateSpline as spline

# error_decrease = spline(np.log(errors), dates , k=1)
# Say errors are decreasing linearly in log space (approximite) and get slope by regression
A = np.vstack([dates, np.ones(len(dates))]).T
m, c = np.linalg.lstsq(A, np.log(errors))[0]

new_errors = np.log(np.array([0.07, 0.034, 0.03, 0.03, 0.0254, 0.02] + final_errors))
print new_errors

new_dates = (new_errors - c) / m
print new_dates

plt.plot(new_dates, np.exp(new_errors))
plt.plot(dates, errors, linestyle='None', marker='+')

plt.savefig("wdm_dates.pdf")

plt.clf()
ax = plt.figure(figsize=(8, 6)).add_subplot(111)
#plt.title("Projected times at which WDM of 1keV can be detected at given mass scales")
plt.xlabel("Year", fontsize=16)
plt.ylabel(r'Error on $\Omega_M $(logarithmic)', fontsize=16)

plt.plot(new_dates, np.exp(new_errors), label="Predicted Error Decrease")
plt.plot(dates, errors, linestyle='None', marker='+', markersize=11, label='Decreases To Date')

plt.plot(new_dates[6], final_errors[0], linestyle='--', marker='.', markersize=11, label=r'$10^{11} M_{\odot}h^{-1}$')
plt.plot(new_dates[7], final_errors[1], linestyle='--', marker='.', markersize=11, label=r'$10^{12} M_{\odot}h^{-1}$')
plt.plot(new_dates[8], final_errors[2], linestyle='--', marker='.', markersize=11, label=r'$10^{13} M_{\odot}h^{-1}$')

plt.plot([2000, 2040], [final_errors[0], final_errors[0]], linestyle='--', color='r')
plt.plot([2000, 2040], [final_errors[1], final_errors[1]], linestyle='--', color='c')
plt.plot([2000, 2040], [final_errors[2], final_errors[2]], linestyle='--', color='m')
plt.yscale('log', basey=2)
plt.legend()
#plt.tight_layout()
ax.yaxis.set_major_formatter(tick.ScalarFormatter())
plt.savefig("wdm_dates_log.eps")

