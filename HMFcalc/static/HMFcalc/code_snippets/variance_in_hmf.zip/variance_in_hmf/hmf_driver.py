'''
Created on Mar 28, 2013

@author: Steven
'''
import matplotlib

import scipy as sp
from hmf import Perturbations
from matplotlib import pyplot as plt
import cosmolopy as cp
plt.switch_backend('Agg')

from cosmo import Cosmo
#===================================================================
#    IMPORT EXTERNAL MODULES
#===================================================================
import numpy as np
import os
import pandas
import time
import sys

#########################################
# Configuration
#########################################
min_M = 10
max_M = 15
M_step = 0.05
approaches = ['PS', 'ST', 'Courtin', 'Jenkins', 'Warren', 'Reed03', 'Reed07', 'Angulo',
               'Tinker', 'Watson', 'Crocce', 'Bhattacharya', 'Behroozi']
cos_to_do = ['WMAP3', 'PLANCK', 'WMAP5', 'WMAP9']
b_frac = 0.155
N_realizations = 5000
chunksize = 500
prefix = ''
num_threads = 0

#the method argument tells it whether to use plain variances, covariances or the full MCMC chain for parameter sampling.
method = "MCMC"  #'cov'  #'MCMC', "var"

#Parameters to vary
params_to_vary = {"omch2":0,
                  "ombh2":1,
                  "n":2,
                  "sigma_8":3
                  }  #H0, ommh2

indices = [val for key, val in params_to_vary.iteritems()]
indices.sort()

#########################################
# MAIN
#########################################

if __name__ == '__main__':
    redshift = float(sys.argv[1])
    method = str(sys.argv[2])
    if method not in ['cov', 'var', 'MCMC']:
        sys.exit("Your method argument was wrong")
    print "Doing analysis using method: ", method
    print "Doing analysis at redshift = ", redshift
    #Create the mass array
    masses = np.arange(min_M, max_M, M_step)

    chunk_arrays = {}
    stats_arrays = {}
    for cosmo in cos_to_do:
        chunk_arrays[cosmo] = {}
        stats_arrays[cosmo] = {}
        for approach in approaches:
            chunk_arrays[cosmo][approach] = pandas.DataFrame(index=10 ** masses)
            stats_arrays[cosmo][approach] = pandas.DataFrame({'mean':np.zeros_like(masses)}, index=10 ** masses)


    init_time = time.time()
    #Loop through all the different cosmologies
    for cosmo in cos_to_do:
        params = np.genfromtxt(cosmo + "_MC.txt")[:, indices]

        if method == 'cov':
            covmat = np.cov(params, rowvar=0)
            mean = np.mean(params, axis=0)
        elif method == 'var':
            var = np.var(params, axis=0)
            mean = np.mean(params, axis=0)

        for i in range(N_realizations):
            cos_p = Cosmo()

            if method == 'var':
                if "ombh2" in params_to_vary:
                    cos_p.set_ombh2(np.random.normal(loc=mean[0], scale=np.sqrt(var[0])))
                if "omch2" in params_to_vary:
                    cos_p.set_omch2(np.random.normal(loc=mean[1], scale=np.sqrt(var[1])))
                if "n" in params_to_vary:
                    cos_p.set_n(np.random.normal(loc=mean[2], scale=np.sqrt(var[2])))
                if "sigma_8" in params_to_vary:
                    cos_p.set_sigma_8(np.random.normal(loc=mean[3], scale=np.sqrt(var[3])))
                if "H0" in params_to_vary:
                    cos_p.set_H0(np.random.normal(loc=mean[4], scale=np.sqrt(var[4])))

            elif method == 'cov':
                the_params = np.random.multivariate_normal(mean, covmat)
                #THIS DOESN'T NECESSARILY WORK IF THE PARAMS ARE NOT IN ORDER AND INCREASE BY 1 :S
                if "ombh2" in params_to_vary:
                    print "setting ombh2 to ", the_params[0]
                    cos_p.set_ombh2(the_params[0])
                if "omch2" in params_to_vary:
                    print "setting omch2 to ", the_params[1]
                    cos_p.set_omch2(the_params[1])
                if "n" in params_to_vary:
                    cos_p.set_n(the_params[2])
                if "sigma_8" in params_to_vary:
                    cos_p.set_sigma_8(the_params[3])
                if "H0" in params_to_vary:
                    cos_p.set_H0(the_params[4])

            elif method == "MCMC":
                rand_int = np.random.randint(low=0, high=params.shape[0])
                if "ombh2" in params_to_vary:
                    cos_p.set_ombh2(params[rand_int, 0])
                if "omch2" in params_to_vary:
                    cos_p.set_omch2(params[rand_int, 1])
                if "n" in params_to_vary:
                    cos_p.set_n(params[rand_int, 2])
                if "sigma_8" in params_to_vary:
                    cos_p.set_sigma_8(params[rand_int, 3])
                if "H0" in params_to_vary:
                    cos_p.set_H0(params[rand_int, 4])


            #Set other parameters by hard definition
            #omh2 = obh2 + och2
            #h = (0.695 * obh2 ** 0.54 / omh2) ** (1 / 1.2)
            #omega_l = 1 - omh2 / h ** 2

            cosmo_list = {"omegab"   : cos_p.get_omegab(),
                          "omegac"   : cos_p.get_omegac(),
                          "omegav"   : cos_p.get_omegav(),
                          "H0"       : cos_p.get_H0(),
                          "sigma_8"  : cos_p.get_sigma_8(),
                          "n"        : cos_p.get_n()
                          }



            pert = Perturbations(M=masses,
                                 z=redshift,
                                 **cosmo_list)

            #Loop over fitting functions
            for approach in approaches:
                pert.update(mf_fit=approach)
                #Save the data
                #mass_func = pert.MassFunction(fsigma=approach)
                chunk_arrays[cosmo][approach][i] = pert.dndlnm


        #if i % chunksize == chunksize - 1:
        #    sys.stdout.write('>')
        #    sys.stdout.flush()

    store = pandas.HDFStore(prefix + 'CosmoTest/' + method + '_data_' + 'z' + str(redshift) + '.h5')
    for approach in approaches:
        for cosmo in cos_to_do:
            store[approach + '_' + cosmo] = chunk_arrays[cosmo][approach]

    store.close()


    print "Time per realization:"
    print (time.time() - init_time) / (N_realizations * len(cos_to_do))
