'''
Created on Apr 15, 2013

@author: Steven
'''
from hmf.Perturbations import Perturbations
import hmf_driver as hmfd
import numpy as np
import pandas
from matplotlib import pyplot as plt
import os

realizations = 100
cosmo = 'PLANCK'
params = ['sigma_8', 'omegab', 'omegac', 'n']
ff = 'ST'
prefix = ''

planck = {"ombh2":0.022068,
          "omch2":0.12029,
          "n":0.9624,
          "sigma_8":0.8344
          }

if __name__ == '__main__':
    os.chdir(prefix)
    masses = np.arange(hmfd.min_M, hmfd.max_M, hmfd.M_step)
    data = {}
    slope = {}
    one_param = pandas.DataFrame({'total':0, 'total-slope':0}, index=masses)



    MC_params = np.genfromtxt('PLANCK_MC.txt')


    for param in params:
        print "===== ", param, "===="
        data[param] = pandas.DataFrame(index=masses)
        slope[param] = pandas.DataFrame(index=masses)

        #Get hard-defined params
        omh2 = planck['ombh2'] + planck['omch2']
        h = (0.695 * planck['ombh2'] ** 0.54 / omh2) ** (1 / 1.2)
        omegav = 1 - omh2 / h ** 2

        #Get list of input parameters to pert
        obh2 = planck['ombh2']
        och2 = planck['omch2']
        H0 = 100 * h
        sigma_8 = planck['sigma_8']
        n = planck['n']
#        cosmo_list = {"omegab"    : planck['ombh2'][0] / h ** 2,
#                       "omegac"   : planck['omch2'][0] / h ** 2,
#                       "omegav"   : omega_l,
#                       "H0"       : 100 * h,
#                       "sigma_8"  : planck['sigma_8'][0],
#                       "n"        : planck['n_s'],
#                       }
        #Create a perturbations class

#        MC_params_shifted = MC_params.copy()

#        if param == "omegab":
#            MC_params_shifted[:, 1] = (MC_params_shifted[:, 1] - np.mean(MC_params_shifted[:, 1])) / np.std(MC_params_shifted[:, 1])
#            MC_params_shifted[:, 2] = (MC_params_shifted[:, 2] - np.mean(MC_params_shifted[:, 2])) / np.std(MC_params_shifted[:, 2])
#            MC_params_shifted[:, 3] = (MC_params_shifted[:, 3] - np.mean(MC_params_shifted[:, 3])) / np.std(MC_params_shifted[:, 3])
#            dist = MC_params_shifted[:, 1] ** 2 + MC_params_shifted[:, 2] ** 2 + MC_params_shifted[:, 3] ** 2
#        elif param == "omegac":
#            MC_params_shifted[:, 0] = (MC_params_shifted[:, 0] - np.mean(MC_params_shifted[:, 0])) / np.std(MC_params_shifted[:, 0])
#            MC_params_shifted[:, 2] = (MC_params_shifted[:, 2] - np.mean(MC_params_shifted[:, 2])) / np.std(MC_params_shifted[:, 2])
#            MC_params_shifted[:, 3] = (MC_params_shifted[:, 3] - np.mean(MC_params_shifted[:, 3])) / np.std(MC_params_shifted[:, 3])
#            dist = MC_params_shifted[:, 0] ** 2 + MC_params_shifted[:, 2] ** 2 + MC_params_shifted[:, 3] ** 2
#        elif param == "sigma_8":
#            MC_params_shifted[:, 1] = (MC_params_shifted[:, 1] - np.mean(MC_params_shifted[:, 1])) / np.std(MC_params_shifted[:, 1])
#            MC_params_shifted[:, 0] = (MC_params_shifted[:, 0] - np.mean(MC_params_shifted[:, 0])) / np.std(MC_params_shifted[:, 0])
#            MC_params_shifted[:, 3] = (MC_params_shifted[:, 3] - np.mean(MC_params_shifted[:, 3])) / np.std(MC_params_shifted[:, 3])
#            dist = MC_params_shifted[:, 1] ** 2 + MC_params_shifted[:, 0] ** 2 + MC_params_shifted[:, 3] ** 2
#        elif param == "n":
#            MC_params_shifted[:, 1] = (MC_params_shifted[:, 1] - np.mean(MC_params_shifted[:, 1])) / np.std(MC_params_shifted[:, 1])
#            MC_params_shifted[:, 2] = (MC_params_shifted[:, 2] - np.mean(MC_params_shifted[:, 2])) / np.std(MC_params_shifted[:, 2])
#            MC_params_shifted[:, 0] = (MC_params_shifted[:, 0] - np.mean(MC_params_shifted[:, 0])) / np.std(MC_params_shifted[:, 0])
#            dist = MC_params_shifted[:, 1] ** 2 + MC_params_shifted[:, 2] ** 2 + MC_params_shifted[:, 0] ** 2

#        indices = np.argsort(dist)[:realizations]

        pert = Perturbations(masses, z=0, omegab=obh2 / h ** 2, omegac=och2 / h ** 2, H0=H0, sigma_8=sigma_8, n=n, omegav=omegav)

        for i in range(realizations):
            if param == 'omegab':
                obh2 = MC_params[np.random.randint(low=0, high=MC_params.shape[0]), 0]
##                omega_m = np.random.normal(loc=hmfd.cosmos[cosmo]['omega_m'][0], scale=hmfd.cosmos[cosmo]['omega_m'][1])
            elif param == 'n':
                n = MC_params[np.random.randint(low=0, high=MC_params.shape[0]), 2]
# #               n_s = np.random.normal(loc=hmfd.cosmos[cosmo]['n_s'][0], scale=hmfd.cosmos[cosmo]['n_s'][1])
            elif param == 'sigma_8':
                sigma_8 = MC_params[np.random.randint(low=0, high=MC_params.shape[0]), 3]
#  #              sigma_8 = np.random.normal(loc=hmfd.cosmos[cosmo]['sigma_8'][0], scale=hmfd.cosmos[cosmo]['sigma_8'][1])
            elif param == 'omegac':
                och2 = MC_params[np.random.randint(low=0, high=MC_params.shape[0]), 1]
#   #             H_0 = np.random.normal(loc=hmfd.cosmos[cosmo]['H_0'][0], scale=hmfd.cosmos[cosmo]['H_0'][1])

#            obh2 = MC_params[i, 0]
#            och2 = MC_params[i, 1]
#            n = MC_params[i, 2]
#            sigma_8 = MC_params[i, 3]

            #Get new hard-defined params
            if param == 'omegab' or param == "omegac":
                omh2 = obh2 + och2
                h = (0.695 * obh2 ** 0.54 / omh2) ** (1 / 1.2)
                omegav = 1 - omh2 / h ** 2
                H0 = 100 * h

            pert.update(omegab=obh2 / h ** 2, omegac=och2 / h ** 2, H0=H0, sigma_8=sigma_8, n=n, omegav=omegav)
            mf = pert.MassFunction(fsigma=ff)
            data[param][i] = mf
            slope[param][i] = np.arctan(np.gradient(mf, hmfd.M_step) / (np.log(10) * 10 ** masses))



        one_param[param] = data[param].quantile(q=0.84, axis=1).sub(data[param].quantile(q=0.16, axis=1)) ** 2
        one_param[param + 'slope'] = slope[param].quantile(q=0.84, axis=1).sub(slope[param].quantile(q=0.16, axis=1)) ** 2

        one_param['total'] = one_param['total'].add(one_param[param])
        one_param['total-slope'] = one_param['total-slope'].add(one_param[param + 'slope'])

    import matplotlib.ticker as tick
    # PLOT IT
    masses = 10 ** masses
    plt.figure(figsize=(15, 6))
    #plt.suptitle("Contributions to Errors from Single Parameters using " + ff, fontsize=20)
    ax = plt.subplot(121)
    #plt.title("Amplitude")
    plt.text(0.5, 1.03, "Amplitude",
         horizontalalignment='center',
         fontsize=20,
         transform=ax.transAxes)
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$', fontsize=16)
    plt.ylabel('Relative Variance', fontsize=16)

    plt.plot(masses, one_param['omegab'].div(one_param['total']), label=r'$\Omega_b h^2$')
    plt.plot(masses, one_param['omegac'].div(one_param['total']), label=r'$\Omega_c h^2$')
    plt.plot(masses, one_param['sigma_8'].div(one_param['total']), label=r'$\sigma_8$')
    plt.plot(masses, one_param['n'].div(one_param['total']), label=r'$n_s$')
    plt.xscale('log')
    plt.subplots_adjust(hspace=0.0, wspace=0.0)
    ticks = ax.xaxis.get_ticklocs()
    ax.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))
    plt.legend()

    ax2 = plt.subplot(122, sharey=ax)
    #plt.title("Slope")
    plt.text(0.5, 1.03, "Slope",
         horizontalalignment='center',
         fontsize=20,
         transform=ax2.transAxes)
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$', fontsize=16)
    # plt.ylabel('Difference in slope between 68% error bounds on singular parameters for Planck')
    plt.plot(masses, one_param['omegabslope'].div(one_param['total-slope']), label=r'$\Omega_M$')
    plt.plot(masses, one_param['omegacslope'].div(one_param['total-slope']), label=r'$H_0$')
    plt.plot(masses, one_param['sigma_8slope'].div(one_param['total-slope']), label=r'$\sigma_8$')
    plt.plot(masses, one_param['nslope'].div(one_param['total-slope']), label=r'$n_s$')
    plt.xscale('log')
    plt.subplots_adjust(hspace=0.0, wspace=0.0)
    plt.setp(ax2.get_yticklabels(), visible=False)
    ticks = ax2.xaxis.get_ticklocs()
    ax2.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))
    plt.savefig('one_parameter_contribution.eps')
    plt.clf()
