'''
Created on Apr 2, 2013

@author: Steven
'''

from hmf import Perturbations
from matplotlib import pyplot as plt
import hmf_driver as hmfd
import numpy as np
import os
import pandas

#########################################
# Configuration
#########################################
approaches = ['PS', 'ST', 'Courtin', 'Jenkins', 'Warren', 'Reed03', 'Reed07', 'Tinker', 'Watson', 'Crocce', 'Angulo', "Bhattacharya", "Behroozi"]
cosmos = ['WMAP3', 'WMAP5', 'WMAP9', 'PLANCK']  # 'WMAP3','WMAP7'
colours = ['DarkGray', 'blue', 'red', 'green', 'purple', 'black']
hatches = ['//', '...', '\\\\', 'OO']
base_cosmo = 'WMAP3'
redshift = 0.0
filename = 'MCMC_data_z0.0.h5'

sub_approaches = ['PS', 'ST', 'Tinker']
approach_to_plot = 'ST'

##### MAIN Program #####
if __name__ == '__main__':
    all_data = pandas.HDFStore(filename)

    # Set up data dictionary
    alldata = {}
    for cosmo in cosmos:
        alldata[cosmo] = {}
        for approach in approaches:
            alldata[cosmo][approach] = all_data[approach + '_' + cosmo]

    all_data.close()

    masses = np.arange(hmfd.min_M, hmfd.max_M, hmfd.M_step)

    # ADD DIFFERENT STATS ETC HERE.
    stats = {}
    for cosmo in cosmos:
        stats[cosmo] = {}
        for approach in approaches:
            stats[cosmo][approach] = pandas.DataFrame({'median':alldata[cosmo][approach].median(axis=1),
                                                       '16q':alldata[cosmo][approach].quantile(q=.16, axis=1),
                                                       '84q':alldata[cosmo][approach].quantile(q=.84, axis=1)})

            stats[cosmo][approach]['error-range'] = stats[cosmo][approach]['84q'].sub(stats[cosmo][approach]['16q'])
            stats[cosmo][approach]['error-range-percent'] = stats[cosmo][approach]['error-range'].div(stats[cosmo][approach]['median']) / 2

    y = stats['PLANCK'][approach_to_plot]['84q'].div(stats['PLANCK'][approach_to_plot]['median'])
    xx = stats['PLANCK'][approach_to_plot]['16q'].div(stats['PLANCK'][approach_to_plot]['median'])

    # CRUDE ATTEMPT AT DERIVATIVE
    print "doing derivs"
    derivs = {}
    for cosmo in cosmos:
        derivs[cosmo] = pandas.DataFrame(index=10 ** masses)
        for col in alldata[cosmo][approach_to_plot].columns:
            derivs[cosmo][col] = np.arctan(np.gradient(np.array(alldata[cosmo][approach_to_plot][col]), hmfd.M_step) / (np.log(10) * 10 ** masses))

    for cosmo in cosmos:
        stats[cosmo][approach_to_plot]['median-slope'] = derivs[cosmo].median(axis=1)
        stats[cosmo][approach_to_plot]['16q-slope'] = derivs[cosmo].quantile(q=0.16, axis=1)
        stats[cosmo][approach_to_plot]['84q-slope'] = derivs[cosmo].quantile(q=0.84, axis=1)
        stats[cosmo][approach_to_plot]['error-range-slope'] = stats[cosmo][approach_to_plot]['84q-slope'].sub(stats[cosmo][approach_to_plot]['16q-slope'])
        stats[cosmo][approach_to_plot]['error-range-slope-percent'] = np.abs(stats[cosmo][approach_to_plot]['error-range-slope'].div(stats[cosmo][approach_to_plot]['median-slope']) / 2)

    print "done derivs"

    # For base cosmology get mean HMF
    base = pandas.DataFrame(index=10 ** masses)
    #cosmo_list = {"omegab"   : hmfd.b_frac * hmfd.cosmos[base_cosmo]['omega_m'][0],
    #              "omegac"      : (1 - hmfd.b_frac) * hmfd.cosmos[base_cosmo]['omega_m'][0],
    #              "omegav"   : 1 - hmfd.cosmos[base_cosmo]['omega_m'][0],
    #              "omegan" : 0.0,
    #              "H0"         : hmfd.cosmos[base_cosmo]['H_0'][0],
    #              'sigma_8':hmfd.cosmos[base_cosmo]['sigma_8'][0],
    #              'n':hmfd.cosmos[base_cosmo]['n_s'][0],
    #              }

#    pert = Perturbations(masses, z=redshift, **cosmo_list)

    for approach in sub_approaches:
        base[approach] = stats[base_cosmo][approach]['median']  #pert.MassFunction(fsigma=approach)

    # Calculate Normalized statistics
    norm_stats = {}
    for cosmo in cosmos:
        norm_stats[cosmo] = {}
        for approach in sub_approaches:
                norm_stats[cosmo][approach] = stats[cosmo][approach].div(base[approach], axis=0)




    ## ERRORS ON FITTING FUNCTIONS ONLY ###
    ff = {}
    ff_derivs = {}
    for cosmo in cosmos:
        ff[cosmo] = pandas.DataFrame(index=10 ** masses)
        ff_derivs[cosmo] = pandas.DataFrame(index=10 ** masses)
        for approach in approaches:
            ff[cosmo][approach] = stats[cosmo][approach]['median']
            ff_derivs[cosmo][approach] = np.arctan(np.gradient(np.array(stats[cosmo][approach]['median']), hmfd.M_step) / (np.log(10) * 10 ** masses))


    ff_stat = pandas.DataFrame(index=10 ** masses)
    for cosmo in cosmos:
        # Amplitudes
        ff_stat[cosmo + 'median'] = ff[cosmo].median(axis=1)
        ff_stat[cosmo + 'q16'] = ff[cosmo].quantile(q=.16, axis=1)
        ff_stat[cosmo + 'q84'] = ff[cosmo].quantile(q=.84, axis=1)
        ff_stat[cosmo + 'error-range'] = np.abs(ff_stat[cosmo + 'q84'].sub(ff_stat[cosmo + 'q16']))
        ff_stat[cosmo + 'error-percent'] = np.abs(ff_stat[cosmo + 'error-range'].div(ff_stat[cosmo + 'median']) / 2)

        # Slopes
        ff_stat[cosmo + 'median-slope'] = ff_derivs[cosmo].median(axis=1)
        ff_stat[cosmo + 'q16-slope'] = ff_derivs[cosmo].quantile(q=.16, axis=1)
        ff_stat[cosmo + 'q84-slope'] = ff_derivs[cosmo].quantile(q=.84, axis=1)
        ff_stat[cosmo + 'error-range-slope'] = np.abs(ff_stat[cosmo + 'q84-slope'].sub(ff_stat[cosmo + 'q16-slope']))
        ff_stat[cosmo + 'error-percent-slope'] = np.abs(ff_stat[cosmo + 'error-range-slope'].div(ff_stat[cosmo + 'median-slope']) / 2)


    # SOME WDM WORK
    wdm_info = pandas.DataFrame(index=10 ** masses)
    wdm_masses = [1.0, 2.0, 5.0, 10.0]
    planck_cosmo = {'omegab':hmfd.b_frac * 0.314,
                    "omegac"   : (1 - hmfd.b_frac) * 0.314,
                    'omegav' : 1 - 0.314,
                    'n'    :0.9616,
                    'sigma_8':0.834,
                    'H0'    :67.4
                    }

    pert = Perturbations(M=masses, z=redshift, mf_fit=approach_to_plot, **planck_cosmo)
    wdm_info['CDM'] = pert.dndlnm
    for wdm in wdm_masses:
        pert.update(wdm_mass=wdm)

        wdm_info[wdm] = pert.dndlnm


    ########################################################################################################################
    ########################################################################################################################
    # NOW MAKE PLOTS!!!
    ########################################################################################################################
    ########################################################################################################################

    masses = 10 ** masses

    import matplotlib.ticker as tick

    # WDM FUNCTIONS
    ax = plt.figure(figsize=(7, 6)).add_subplot(111)
    #plt.title("Comparison of WDM models with CDM errors")
    plt.ylabel(r'Ratio of Logarithmic Mass Functions $ \left(\frac{dn}{d \ln M}\right) / \left( \frac{dn}{d \ln M} \right)_{PLANCK} $')
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$')
    plt.plot(masses, stats['PLANCK'][approach_to_plot]['median'].div(stats['PLANCK'][approach_to_plot]['median']), color=colours[0], label="CDM")
    plt.fill_between(masses, xx, y, facecolor=colours[0], alpha=0.5)
    for i, wdm in enumerate(wdm_masses):
        plt.plot(masses, wdm_info[wdm].div(stats['PLANCK'][approach_to_plot]['median']), color=colours[i + 1], label="WDM Mass = " + str(wdm) + ' keV')

    plt.xscale('log')
    plt.yscale('log', basey=2)
    ax.yaxis.set_major_formatter(tick.ScalarFormatter())
    plt.yticks([0.5, 0.75, 1, 1.5, 2])
    plt.legend(loc=2, fancybox=True)
    plt.tight_layout()
    plt.savefig('WDM_functions_z' + str(int(redshift)) + '.eps')
    plt.clf()



    # PLAIN MASS FUNCTIONS FOR ALL FITTING FUNCTIONS
    lines = ["-", "--", "-.", ":"]
    plt.figure(figsize=(7, 6)).add_subplot(111)
    #plt.title("Planck Mass Function for Various Fitting Functions")
    plt.ylabel(r'Mass Function, $ \left(\frac{dn}{d \ln M}\right) h^3 Mpc^{-3}$')
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$')
    plots = []
    for i, approach in enumerate(approaches):
        plots.append(plt.plot(masses, stats['PLANCK'][approach]['median'], color=colours[i % len(colours)], linestyle=lines[(i / 4) % 7], label=approach)[0])


    plt.xscale('log')
    plt.yscale('log')
    pl1 = plt.legend(plots[:len(approaches) / 2], approaches[:len(approaches) / 2], loc=3, fancybox=True)
    pl2 = plt.legend(plots[len(approaches) / 2:], approaches[len(approaches) / 2:], loc=1, fancybox=True)
    plt.gca().add_artist(pl1)
    plt.tight_layout()
    plt.savefig('HMF_z' + str(int(redshift)) + '.eps')
    plt.clf()

    # COMPARATIVE MASS FUNCTIONS WITH ERROR RANGES
    plt.figure(figsize=(len(sub_approaches) * 6 , 6.5))
    #plt.suptitle("Comparitive Mass Functions", fontsize=20)
    for i, approach in enumerate(sub_approaches):
        sub = 100 + 10 * len(sub_approaches) + i + 1
        if i == 0:
            ax = plt.subplot(sub)
            plt.minorticks_on()
            plt.text(0.5, 1.03, approach,
                    horizontalalignment='center',
                    fontsize=20,
                    transform=ax.transAxes)
        else:
            ax2 = plt.subplot(sub, sharey=ax)
            plt.text(0.5, 1.03, approach,
                     horizontalalignment='center',
                     fontsize=20,
                     transform=ax2.transAxes)


        if i == 0:
            plt.ylabel(r'$ \left(\frac{dn}{d \ln M}\right) / \left( \frac{dn}{d \ln M} \right)_{' + str(base_cosmo) + '} $', fontsize=16)
        legend = []
        for j, cosmo in enumerate(cosmos):
            plt.xlabel(r'Mass $(M_{\odot}h^{-1})$', fontsize=16)
            plt.plot(masses, norm_stats[cosmo][approach]['median'], linestyle='None', color=colours[j], label=cosmo)
            #plt.fill_between(masses, norm_stats[cosmo][approach]['16q'], norm_stats[cosmo][approach]['84q'],
             #                         facecolor=colours[j], alpha=0.35, hatch='/')

            plt.fill_between(masses, norm_stats[cosmo][approach]['16q'], norm_stats[cosmo][approach]['84q'],
                             hatch=hatches[j], facecolor=(1, 1, 1, 0), color=colours[j])

            legend.append(plt.Rectangle((0, 0), 1, 1, fill=False, color=colours[j], hatch=hatches[j]))

        plt.subplots_adjust(hspace=0.0, wspace=0.0)
        plt.xscale('log')
        plt.yscale('log', basey=2)

        if i == 0:
            ticks = ax.xaxis.get_ticklocs()
            ax.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))
        else:
            ticks = ax2.xaxis.get_ticklocs()
            ax2.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))
            plt.setp(ax2.get_yticklabels(), visible=False)


        if i == 0:
            plt.legend(legend, cosmos, loc=3, fancybox=True)

    ax.yaxis.set_major_formatter(tick.ScalarFormatter())
    plt.ylim((0.25, 4))
    #plt.tight_layout(h_pad=0.0, w_pad=0.0)
    plt.savefig('Comparative_HMF_z' + str(int(redshift)) + '.eps')
    plt.clf()


    # UNCERTAINTY IN AMPLITUDE AND SLOPE
    plt.figure(figsize=(12, 6))
    ax = plt.subplot(121)
    plt.text(0.5, 1.03, "Amplitude",
         horizontalalignment='center',
         fontsize=20,
         transform=ax.transAxes)
    plt.ylabel(r'Fractional uncertainty', fontsize=16)
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$', fontsize=16)
    plt.plot(masses, np.empty(len(masses)) * np.nan, linestyle='--', label="Error in Fitting Functions")
    for j, cosmo in enumerate(cosmos):
        plt.plot(masses, stats[cosmo][approach_to_plot]['error-range-percent'], color=colours[j], label=cosmo)
        plt.plot(masses, ff_stat[cosmo + 'error-percent'], color=colours[j], linestyle='--')
    plt.xscale('log')
    plt.minorticks_on()
    plt.subplots_adjust(hspace=0.0, wspace=0.0)
    ticks = ax.xaxis.get_ticklocs()
    ax.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))
    plt.legend(loc=2, fancybox=True)

    ax2 = plt.subplot(122, sharey=ax)
    plt.text(0.5, 1.03, "Slope",
         horizontalalignment='center',
         fontsize=20,
         transform=ax2.transAxes)
    plt.xlabel(r'Mass $(M_{\odot}h^{-1})$', fontsize=16)
    plt.plot(masses, np.empty(len(masses)) * np.nan, linestyle='--', label="Error in Fitting Functions")
    for j, cosmo in enumerate(cosmos):
        plt.plot(masses, stats[cosmo][approach_to_plot]['error-range-slope-percent'], color=colours[j], label=cosmo)
        plt.plot(masses, ff_stat[cosmo + 'error-percent-slope'], color=colours[j], linestyle='--')

    plt.subplots_adjust(hspace=0.0, wspace=0.0)
    plt.setp(ax2.get_yticklabels(), visible=False)
    plt.xscale('log')
    ticks = ax2.xaxis.get_ticklocs()
    ax2.xaxis.set_major_locator(tick.FixedLocator(ticks[1:]))

    plt.savefig('Error_z' + str(int(redshift)) + '.eps')
    plt.clf()


    # DECREASE OF UNCERTAINTY
#    plt.figure( figsize=(15,6))
#    plt.suptitle("Comparitive Uncertainties")
#    ax = plt.subplot(121)
#    plt.title("Amplitude")
#    plt.ylabel(r'Ratio of 68% amplitude errors to '+base_cosmo+' errors')
#    plt.xlabel(r'Mass $(M_{sun}h^{-1})$')
#
#    for j,cosmo in enumerate(cosmos):
#        if cosmo == base_cosmo:
#            pass
#        else:
#            plt.xlabel(r'Mass $(M_{sun}h^{-1})$')
#            plt.plot(masses,stats[cosmo][approach]['error-range'].div(stats[base_cosmo][approach]['error-range']),color=colours[j],label=cosmo)
#
#    leg =plt.legend(loc=2,fancybox=True)
#    leg.get_frame().set_alpha(0.7)
#    plt.xscale('log')
#    plt.yscale(yscale)
#
#    plt.subplot(122,sharey=ax)
#    plt.title("Slope")
#    plt.ylabel(r'Comparative uncertainty in slope')
#
#    for j,cosmo in enumerate(cosmos):
#        if cosmo == base_cosmo:
#            pass
#        else:
#            plt.xlabel(r'Mass $(M_{sun}h^{-1})$')
#            plt.plot(masses,stats[cosmo][approach]['error-range-slope'].div(stats[base_cosmo][approach]['error-range-slope']),color=colours[j],label=cosmo)
#
#    plt.xscale('log')
#    plt.yscale(yscale)
#    plt.savefig('error_decrease_z'+str(redshift)+'.pdf')
#    plt.clf()





